﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Project_form1
{
    public partial class userDashboard : Form
    {
        SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-S0HLTR7\SQLEXPRESS;Initial Catalog=ProjectDB; Integrated Security=True");

        public userDashboard()
        {
            InitializeComponent();
        }

        public void LoadComboBox(string resturant)
        {
            conn.Open();
            string qry = "Select itemName from items WHERE itemResturantName=@ResturantName";
            SqlCommand cmd = new SqlCommand(qry, conn);
            cmd.Parameters.AddWithValue("@ResturantName", resturant);
            SqlDataReader reader = cmd.ExecuteReader();
            cmboxItems.Items.Clear();
            while (reader.Read())
            {
                string item = reader["itemName"].ToString();
                cmboxItems.Items.Add(item);
            }
            conn.Close();
        }

        public void LoadCities()
        {
            conn.Open();
            string qry = "Select distinct ResturantCity from resturant";
            SqlCommand cmd = new SqlCommand(qry, conn);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                string city = reader["ResturantCity"].ToString();
                cmboxCity.Items.Add(city);
            }
            conn.Close();
        }


        public void LoadResturants(string city)
        {
            conn.Open();
            string qry = "Select ResturantName from resturant WHERE ResturantCity = @ResturantCity";
            SqlCommand cmd = new SqlCommand(qry, conn);
            cmd.Parameters.AddWithValue("@ResturantCity", city);
            SqlDataReader reader = cmd.ExecuteReader();

            cmboxResturants.Items.Clear();
            while (reader.Read())
            {
                string restaurant = reader["ResturantName"].ToString();
                cmboxResturants.Items.Add(restaurant);
            }
            conn.Close();
        }

        private void cmboxCity_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmboxCity.SelectedItem != null)
            {
                string selectedCity = cmboxCity.SelectedItem.ToString();
                LoadResturants(selectedCity);

                // Clear the display of comboBox Resturant when differnt value selected in cities combobox
                cmboxResturants.SelectedIndex = -1;
                cmboxResturants.Text = string.Empty;
                // Clear the display of comboBox items when differnt value selected in cities combobox
                cmboxItems.SelectedIndex = -1;
                cmboxItems.Text = string.Empty;
            }

        }

        private void userDashboard_Load(object sender, EventArgs e)
        {
            LoadCities();
        }

        private void cmboxResturants_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(cmboxResturants.SelectedItem != null)
            {
                string selectedResturant = cmboxResturants.SelectedItem.ToString();
                LoadComboBox(selectedResturant);

                // Clear the display of comboBox items when differnt value selected in cities combobox
                cmboxItems.SelectedIndex = -1;
                cmboxItems.Text = string.Empty;
            }

        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            string name = txtName.Text;
            string email = txtEmail.Text;
            string phone = txtPhone.Text;
            string address = txtAddress.Text;
            string city = cmboxCity.Text;
            string resturants=cmboxResturants.Text;
            string items=cmboxItems.Text;
            int quantity = Convert.ToInt32(txtQuantity.Text);

            // Regex pattern for email validation
            string pattern_email = @"^[a-zA-Z0-9_.+-]+@[a-z]+\.[a-z]+$";
            string pattern_phone = @"^\d{11}$";

            // Check if the email matches the pattern
            bool isValidEmail = Regex.IsMatch(email, pattern_email);
            bool isValidPhone = Regex.IsMatch(phone, pattern_phone);

            if (!isValidEmail)
            {
                MessageBox.Show("Invalid email address", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (!isValidPhone)
            {
                MessageBox.Show("Invalid phone number", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }            
            else if (String.IsNullOrEmpty(txtName.Text))
            {
                MessageBox.Show("Please Enter name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (String.IsNullOrEmpty(txtEmail.Text))
            {
                MessageBox.Show("Please Enter Email Address", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (String.IsNullOrEmpty(txtPhone.Text))
            {
                MessageBox.Show("Please Enter Phone number", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (String.IsNullOrEmpty(txtAddress.Text))
            {
                MessageBox.Show("Please Enter Your address", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (String.IsNullOrEmpty(txtQuantity.Text))
            {
                MessageBox.Show("Please Enter items Quantity", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (cmboxItems.SelectedIndex==-1)
            {
                MessageBox.Show("Please Select Items", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (cmboxResturants.SelectedIndex == -1)
            {
                MessageBox.Show("Please Select Resturants", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                conn.Open();
                string qry = "Insert into orders_inprogress values ('" + name + "','" + email + "','" + phone + "','" + address + "','" + city + "','" + resturants + "','" + items + "','" +  quantity + "')";
                SqlCommand cmd = new SqlCommand(qry, conn);
                int res = cmd.ExecuteNonQuery();
                if (res > 0)
                {
                    MessageBox.Show("Order Confirmed");
                    txtAddress.Clear();
                    txtQuantity.Clear();
                    txtPhone.Clear();
                    txtName.Clear();
                    txtEmail.Clear();
                    cmboxCity.SelectedIndex = -1;
                    cmboxItems.SelectedIndex = -1;
                    cmboxResturants.SelectedIndex = -1;
                    conn.Close();
                }

            }
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            Form1 obj=new Form1();
            this.Hide();
            obj.Show();
        }


    }
}

