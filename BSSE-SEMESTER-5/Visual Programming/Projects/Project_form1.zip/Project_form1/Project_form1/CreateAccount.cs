﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_form1
{
    public partial class CreateAccount : Form
    {
        public CreateAccount()
        {
            InitializeComponent();
        }

        private void cbshow_CheckedChanged(object sender, EventArgs e)
        {
            if(cbshow.Checked)
            {
                txtConPwd.UseSystemPasswordChar = false;
                txtpwd.UseSystemPasswordChar = false;
            }
            else
            {
                txtConPwd.UseSystemPasswordChar = true;
                txtpwd.UseSystemPasswordChar = true;
            }
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            String username=txtuser.Text;
            String password=txtpwd.Text;
            if (txtpwd.Text == txtConPwd.Text)
            {
                SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-S0HLTR7\SQLEXPRESS; Initial Catalog=ProjectDB; Integrated Security=True");
                conn.Open();
                if (String.IsNullOrEmpty(txtuser.Text))
                {
                    MessageBox.Show("Please Enter user name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else if (String.IsNullOrEmpty(txtpwd.Text))
                {
                    MessageBox.Show("Please Enter Password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else if (String.IsNullOrEmpty(txtConPwd.Text))
                {
                    MessageBox.Show("Please Enter Password in confirm password field", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    string qry = "Insert into user_login values ('"+username+"','" + password + "')";
                    SqlCommand cmd = new SqlCommand(qry, conn);
                    int res = cmd.ExecuteNonQuery();
                    if (res > 0)
                    {
                        MessageBox.Show("Account Created");
                        txtuser.Text = "";
                        txtpwd.Text = "";
                        txtConPwd.Text = "";
                    }
                }          
            }
            else
            {
                MessageBox.Show("Password must be similiar", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            Form1 obj= new Form1();
            this.Hide();
            obj.Show();
           
        }

    }
}
