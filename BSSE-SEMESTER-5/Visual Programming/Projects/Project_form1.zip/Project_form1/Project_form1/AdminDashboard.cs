﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace Project_form1
{
    public partial class adminDashboard : Form
    {
        //orders completed
        DataTable dtorderscomp = new DataTable();
        //order inprogress
        DataTable dt=new DataTable();
        SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-S0HLTR7\SQLEXPRESS; Initial Catalog= ProjectDB; Integrated Security=True");
        public adminDashboard()
        {
            InitializeComponent();
            LoadComboBoxOrders();
            LoadItemResturants();
        }

        //add items
        private void btnAdd_Click(object sender, EventArgs e)
        {
            string itemname= txtItemName.Text;
            string itemid=txtItemId.Text;
            string itemResturantName= cmboxItemRest.Text;


            conn.Open();
            if (String.IsNullOrEmpty(txtItemName.Text))
            {
                MessageBox.Show("Please Enter item name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (String.IsNullOrEmpty(txtItemId.Text))
            {
                MessageBox.Show("Please Enter Item Id", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (String.IsNullOrEmpty(cmboxItemRest.Text))
            {
                MessageBox.Show("Please Enter Item Resturant", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                string qryCheck = "SELECT COUNT(*) FROM items WHERE itemId = @ItemId";
                SqlCommand cmdCheck = new SqlCommand(qryCheck, conn);
                cmdCheck.Parameters.AddWithValue("@ItemId", itemid);

                int count = (int)cmdCheck.ExecuteScalar();

                if (count > 0)
                {
                    MessageBox.Show("Item ID already exists.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    string qry = "Insert into items values ('" + itemid + "','" + itemname + "','" + itemResturantName + "')";
                    SqlCommand cmd = new SqlCommand(qry, conn);
                    int res = cmd.ExecuteNonQuery();
                    if (res > 0)
                    {
                        MessageBox.Show("Item Added");
                        clear_items_fields();
                    }
                }
                
            }
            conn.Close();
        }

        private void btnAddRest_Click(object sender, EventArgs e)
        {
            //class object for changing case
            TextInfo textInfo = CultureInfo.CurrentCulture.TextInfo;
            string restname = textInfo.ToTitleCase(txtRestName.Text.ToLower());
            string restcity = textInfo.ToTitleCase(txtrestcity.Text.ToLower());
            string restid = txtRestId.Text;

            conn.Open();
            if (String.IsNullOrEmpty(txtRestName.Text))
            {
                MessageBox.Show("Please Enter Resturant name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (String.IsNullOrEmpty(txtrestcity.Text))
            {
                MessageBox.Show("Please Enter Resturant City", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (String.IsNullOrEmpty(txtRestId.Text))
            {
                MessageBox.Show("Please Enter Resturant Id", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                string qryCheck = "SELECT COUNT(*) FROM resturant WHERE ResturantId = @RestId";
                SqlCommand cmdCheck = new SqlCommand(qryCheck, conn);
                cmdCheck.Parameters.AddWithValue("@RestId", restid);

                int count = (int)cmdCheck.ExecuteScalar();

                if (count > 0)
                {
                    MessageBox.Show("Resturant ID already exists.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    string qry = "INSERT INTO resturant VALUES ('" + restid + "','" + restname + "','" + restcity + "')";
                    SqlCommand cmd = new SqlCommand(qry, conn);
                    int res = cmd.ExecuteNonQuery();
                    if (res > 0)
                    {
                        MessageBox.Show("Restaurant Added");
                        clear_resturants_fields();
                    }
                }
            }
            conn.Close();

        }

        private void btnDeleteItems_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtItemId.Text))
            {
                MessageBox.Show("Please enter item id to delete", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                int item_id = Convert.ToInt32(txtItemId.Text);
                if (item_id != 0 && txtItemId.Text != "" )
                {
                    
                    conn.Open();
                    SqlCommand cd = new SqlCommand("delete items where itemId=@itemid", conn);
                    cd.Parameters.AddWithValue("@itemid", item_id);
                    cd.ExecuteNonQuery();
                    MessageBox.Show("Record  Deleted Successfully!");
                    clear_items_fields();
                    conn.Close();
                }
                else
                {
                    MessageBox.Show("Please enter item id to delete", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnDeleteRest_Click(object sender, EventArgs e)
        {
            if(string.IsNullOrEmpty(txtRestId.Text))
            {
                MessageBox.Show("Please enter resturant id to delete", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                int rest_id = Convert.ToInt32(txtRestId.Text);
                if (rest_id != 0)
                {
                    conn.Open();
                    SqlCommand cd = new SqlCommand("delete resturant where ResturantId=@restid", conn);
                    cd.Parameters.AddWithValue("@restid", rest_id);
                    cd.ExecuteNonQuery();
                    MessageBox.Show("Resturant Deleted Successfully!");
                    clear_resturants_fields();
                    conn.Close();
                }
                else
                {
                    MessageBox.Show("Please enter resturant id to delete", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }   
        }

        private void btnUpdateItems_Click(object sender, EventArgs e)
        {
            if (txtItemId.Text != "" && txtItemName.Text != "" && cmboxItemRest.Text != "")
            {
                conn.Open();
                SqlCommand cmnd = new SqlCommand("update items set itemName=@itemname,itemResturantName=@itemresturantname where itemId=@itemid", conn);
                int item_id = Convert.ToInt32(txtItemId.Text);
                cmnd.Parameters.AddWithValue("@itemid", item_id);
                cmnd.Parameters.AddWithValue("@itemname", txtItemName.Text);
                cmnd.Parameters.AddWithValue("@itemresturantname", cmboxItemRest.Text);
                cmnd.ExecuteNonQuery();
                conn.Close();
                MessageBox.Show("Items Details Updated Successfully");
                clear_items_fields();
                conn.Close();
            }
            else
            {
                MessageBox.Show("Please enter mandatory details!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnUpdateRest_Click(object sender, EventArgs e)
        {
            if (txtRestId.Text != "" && txtRestName.Text != "" && txtrestcity.Text != "")
            {   
                conn.Open();
                SqlCommand cmnd = new SqlCommand("update resturant set ResturantName=@resturantname,ResturantCity=@resturantcity where ResturantId=@resturantid", conn);
                int rest_id = Convert.ToInt32(txtRestId.Text);
                cmnd.Parameters.AddWithValue("@resturantid", rest_id);
                cmnd.Parameters.AddWithValue("@resturantname", txtRestName.Text);
                cmnd.Parameters.AddWithValue("@resturantcity", txtrestcity.Text);
                cmnd.ExecuteNonQuery();
                conn.Close();
                MessageBox.Show("Resturant Details Updated Successfully");
                clear_resturants_fields();
            }

            else
            {
                MessageBox.Show("Please enter mandatory details!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        void LoadOrdersInProgress()
        {
            string qry = "Select * from orders_inprogress";
            SqlCommand cmd = new SqlCommand(qry, conn);
            SqlDataAdapter adpp = new SqlDataAdapter(cmd);
            dt.Clear();
            adpp.Fill(dt);
            dataGridView1.DataSource = dt;
        }
        
        void LoadCompletedOrders()
        {
            string qry = "Select * from orders_completed";
            SqlCommand cmd = new SqlCommand(qry, conn);
            SqlDataAdapter adpp = new SqlDataAdapter(cmd);
            dtorderscomp.Clear();
            adpp.Fill(dtorderscomp);
            dataGridView1.DataSource = dtorderscomp;
        }

        void LoadComboBoxOrders()
        {
            cmboxOrderInfo.Items.Add("Orders InProgress");
            cmboxOrderInfo.Items.Add("Orders Completed");
            cmboxOrderInfo.SelectedItem = "Orders InProgress";
        }

        private void cmboxOrderInfo_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedStatus = cmboxOrderInfo.SelectedItem.ToString();

            if (selectedStatus == "Orders InProgress")
            {
                btnRemoveOrder.Visible = false;
                btnOrderComp.Visible = true;
                LoadOrdersInProgress();
            }
            else if (selectedStatus == "Orders Completed")
            {
                btnOrderComp.Visible = false;
                btnRemoveOrder.Visible = true;
                LoadCompletedOrders();
            }
        }

        private void btnRemoveOrder_Click(object sender, EventArgs e)
        {
            if (txtOrderId.Text != "")
            {
                string qry = "DELETE from orders_completed WHERE order_id=@orderid";
                SqlCommand cmd = new SqlCommand(qry, conn);
                int orderid = Convert.ToInt32(txtOrderId.Text);
                cmd.Parameters.AddWithValue("@orderid", orderid);
                SqlDataAdapter adpp = new SqlDataAdapter(cmd);
                adpp.Fill(dt);
                MessageBox.Show("Order Removed Successfully");
                txtOrderId.Clear();
            }
            else
            {
                MessageBox.Show("Enter Order Id", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void btnOrderComp_Click(object sender, EventArgs e)
        {
            if (txtOrderId.Text!="")
            {
                int orderid = Convert.ToInt32(txtOrderId.Text);
                // Insert into orders_completed
                string insertQuery = "INSERT INTO orders_completed (Name, Email, Phone, Address, City, Resturant, Items, Quantity) SELECT Name, Email, Phone, Address, City, Resturant, Items, Quantity FROM orders_inprogress WHERE order_id = @orderid";
                SqlCommand insertCmd = new SqlCommand(insertQuery, conn);
                insertCmd.Parameters.AddWithValue("@orderid", orderid);
                SqlDataAdapter adp = new SqlDataAdapter(insertCmd);
                adp.Fill(dtorderscomp);
                // Delete from orders_inprogress
                string deleteQuery = "DELETE FROM orders_inprogress WHERE order_id = @orderid";
                SqlCommand deleteCmd = new SqlCommand(deleteQuery, conn);
                deleteCmd.Parameters.AddWithValue("@orderid", orderid);
                SqlDataAdapter adpp = new SqlDataAdapter(deleteCmd);
                adpp.Fill(dt);
                MessageBox.Show("Order Completed Successfully");
                txtOrderId.Clear();
            }
            else
            {
                MessageBox.Show("Enter Order Id", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void LoadItemResturants()
        {
            conn.Open();
            string qry = "Select ResturantName from resturant";
            SqlCommand cmd = new SqlCommand(qry, conn);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                string resturant = reader["ResturantName"].ToString();
                cmboxItemRest.Items.Add(resturant);
            }
            conn.Close();
        }
        private void btnLogout_Click(object sender, EventArgs e)
        {
            Form1 obj = new Form1();
            this.Hide();
            obj.Show();
        }

        public void clear_resturants_fields()
        {
            txtRestId.Text = string.Empty;
            txtRestName.Text = string.Empty;
            txtrestcity.Text = string.Empty;
        }

        public void clear_items_fields()
        {
            txtRestId.Text = string.Empty;
            txtRestName.Text = string.Empty;
            txtrestcity.Text = string.Empty;
        }

    }
}
