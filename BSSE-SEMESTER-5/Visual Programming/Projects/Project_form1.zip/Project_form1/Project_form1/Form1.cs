﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_form1
{
    public partial class Form1 : Form
    {
        SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-S0HLTR7\SQLEXPRESS; Initial Catalog=ProjectDB; Integrated Security=True");

        public Form1()
        {
            InitializeComponent();
        }
        // user create account
        private void button1_Click(object sender, EventArgs e)
        {

            CreateAccount obj = new CreateAccount();
            this.Hide();
            obj.Show();

        }
        // User Login Button
        private void btn_login_Click(object sender, EventArgs e)
        {
            String qry = "SELECT * FROM user_login WHERE username = '" + txtuser.Text + "' and password = '" + txtpwd.Text + "'";
            SqlDataAdapter adp = new SqlDataAdapter(qry, conn);
            DataTable dt = new DataTable();
            adp.Fill(dt);
            if (dt.Rows.Count == 1)
            {
                userDashboard obj = new userDashboard();
                this.Hide();
                obj.Show();
            }
            else if (String.IsNullOrEmpty(txtuser.Text))
            {
                MessageBox.Show("Please Enter usename", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (String.IsNullOrEmpty(txtpwd.Text))
            {
                MessageBox.Show("Please Enter Password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                MessageBox.Show("Invalid Username or Password!!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //Admin login Button
        private void btn_loginAd_Click(object sender, EventArgs e)
        {
            String qry = "SELECT * FROM admin_login WHERE username = '" + txtAdmin.Text + "' and password = '" + txtAdPwd.Text + "'";
            SqlDataAdapter adp = new SqlDataAdapter(qry, conn);
            DataTable dt = new DataTable();
            adp.Fill(dt);
            if (dt.Rows.Count == 1)
            {
                adminDashboard obj = new adminDashboard();
                this.Hide();
                obj.Show();
            }
            else if (String.IsNullOrEmpty(txtAdmin.Text))
            {
                MessageBox.Show("Please Enter usename", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (String.IsNullOrEmpty(txtAdPwd.Text))
            {
                MessageBox.Show("Please Enter Password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                MessageBox.Show("Invalid username or password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //show password for user
        private void cbshow_CheckedChanged(object sender, EventArgs e)
        {
            if (cbshow.Checked)
            {
                txtpwd.UseSystemPasswordChar = false;
            }
            else
            {
                txtpwd.UseSystemPasswordChar = true;
            }
        }

        //show password for admin
        private void cbshow1pwd_CheckedChanged(object sender, EventArgs e)
        {
            if (cbshow1pwd.Checked)
            {
                txtAdPwd.UseSystemPasswordChar = false;
            }
            else
            {
                txtAdPwd.UseSystemPasswordChar = true;
            }
            
        }
    }
}

